package org.elu.akka

import akka.actor.{ActorSystem, Props}
import akka.cluster.sharding.{ClusterSharding, ClusterShardingSettings}

/** Created by luhtonen on 12/04/16. */
object PersistentFSMApp extends App {
  import Account._

  val system = ActorSystem("persistent-fsm-actors")

  val accountRegion = ClusterSharding(system).start(
    typeName = Account.shardName,
    entityProps = Account.props,
    settings = ClusterShardingSettings(system),
    extractEntityId = Account.idExtractor,
    extractShardId = Account.shardResolver)


  accountRegion ! Operation("12",1000, CR)
  accountRegion ! Operation("12",10, DR)

  accountRegion ! Operation("13",1000, CR)
  accountRegion ! Operation("13",10, DR)

  Thread.sleep(20000)
  system.terminate()
}
